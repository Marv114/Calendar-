const calendarGrid = document.getElementById('calendarGrid');
const monthYear = document.getElementById('monthYear');
const prevMonthButton = document.getElementById('prevMonth');
const nextMonthButton = document.getElementById('nextMonth');
const addEventButton = document.getElementById('addEventButton');
const eventModal = document.getElementById('eventModal');
const closeModal = document.querySelector('.close');
const saveEventButton = document.getElementById('saveEventButton');
const eventTitleInput = document.getElementById('eventTitle');
const eventDateInput = document.getElementById('eventDate');

let currentDate = new Date();
let events = {}; // Store events by date

function renderCalendar(date) {
    
   // Clear the previous calendar
   calendarGrid.innerHTML = '';

   // Set the current month and year
   const month = date.getMonth();
   const year = date.getFullYear();
   
   monthYear.textContent = date.toLocaleString('default', { month: 'long', year: 'numeric' });

   // Get the first day of the month
   const firstDayOfMonth = new Date(year, month, 1);
   
   // Get the last day of the month
   const lastDayOfMonth = new Date(year, month + 1, 0);
   
   // Get the number of days in the month
   const totalDaysInMonth = lastDayOfMonth.getDate();

   // Get the starting day of the week (0-6)
   const startDay = firstDayOfMonth.getDay();

   // Create empty cells for days before the first day of the month
   for (let i = 0; i < startDay; i++) {
       const emptyCell = document.createElement('div');
       emptyCell.classList.add('day');
       calendarGrid.appendChild(emptyCell);
   }

   // Create cells for each day of the month
   for (let day = 1; day <= totalDaysInMonth; day++) {
       const dayCell = document.createElement('div');
       dayCell.classList.add('day');
       dayCell.textContent = day;

       // Highlight current day
       if (day === new Date().getDate() && month === new Date().getMonth() && year === new Date().getFullYear()) {
           dayCell.classList.add('current-day');
       }

       // Check if there are events for this day
       const eventKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
       if (events[eventKey]) {
           const eventIndicator = document.createElement('div');
           eventIndicator.classList.add('event');
           eventIndicator.textContent = `${events[eventKey]}!`;
           dayCell.appendChild(eventIndicator);
       }

       // Add click event to open modal for adding an event
       dayCell.addEventListener('click', () => openModal(day));
       
       calendarGrid.appendChild(dayCell);
   }
}

// Open modal to add an event
function openModal(day) {
   eventModal.style.display = 'block';
   eventDateInput.value = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

// Close modal
closeModal.addEventListener('click', () => {
   eventModal.style.display = 'none';
});

// Save event
saveEventButton.addEventListener('click', () => {
   const title = eventTitleInput.value.trim();
   const dateValue = eventDateInput.value;

   if (title && dateValue) {
       events[dateValue] = title; // Store event by date
       renderCalendar(currentDate); // Re-render calendar to show new event
       eventTitleInput.value = ''; // Clear input field
       eventModal.style.display = 'none'; // Close modal
   }
});

// Event listeners for buttons
prevMonthButton.addEventListener('click', () => {
   currentDate.setMonth(currentDate.getMonth() - 1);
   renderCalendar(currentDate);
});

nextMonthButton.addEventListener('click', () => {
   currentDate.setMonth(currentDate.getMonth() + 1);
   renderCalendar(currentDate);
});

// Add Event button functionality
addEventButton.addEventListener('click', () => openModal(new Date().getDate()));

// Initial render
renderCalendar(currentDate);

// Close modal when clicking outside of it
window.onclick = function(event) {
   if (event.target === eventModal) {
      eventModal.style.display = "none";
   }
}
